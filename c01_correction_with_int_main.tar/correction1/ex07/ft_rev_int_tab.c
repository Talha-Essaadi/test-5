/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: momousta <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/19 01:16:17 by momousta          #+#    #+#             */
/*   Updated: 2025/08/19 17:05:44 by momousta         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_rev_int_tab(int *tab, int size)

{
	int	start;
	int	a;
	int	end;

	start = 0;
	end = size -1;
	while (start < end)
	{
		a = tab[start];
		tab[start] = tab[end];
		tab[end] = a;
		end--;
		start++;
	}
}


#include <stdio.h>

int main() {
 
    int arr[] = {1,2,3,4,5,6,7,8};
    int x = 0;
    while(x < 8)
    {
        printf("%d", arr[x]);
        x++;
    }
 
    ft_rev_int_tab(arr , 8);
    printf("\n");
    x = 0;
    while(x < 8)
    {
        printf("%d", arr[x]);
        x++;
    }
    return 0;
}

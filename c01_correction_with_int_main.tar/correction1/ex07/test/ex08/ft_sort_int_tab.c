/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: momousta <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/19 15:00:07 by momousta          #+#    #+#             */
/*   Updated: 2025/08/19 17:09:08 by momousta         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_sort_int_tab(int *tab, int size)
{
	int	start;
	int	a;

	start = 0;
	while (start + 1 != size)
	{
		if (tab[start] > tab[start + 1])
		{
			a = tab[start];
			tab[start] = tab[start + 1];
			tab[start + 1] = a;
			start = 0;
		}
		else
		{
			start++;
		}
	}
}



#include <stdio.h>

int main() {

int arr[] = {6,4,3,8,2,9,1,5,7};
    int x = 0;

    // Print the array before reversing
    while(x < 8) {
        printf("%d ", arr[x]);
        x++;
    }

    ft_sort_int_tab(arr, 8);
    printf("\n");

    // Print the array after reversing
    x = 0;
    while(x < 8) {
        printf("%d ", arr[x]);
        x++;
    }
    return 0;
}

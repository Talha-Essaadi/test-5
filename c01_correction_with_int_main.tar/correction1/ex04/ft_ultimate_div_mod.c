/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: momousta <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/17 21:22:43 by momousta          #+#    #+#             */
/*   Updated: 2025/08/19 16:46:27 by momousta         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_ultimate_div_mod(int *a, int *b)
{
	int	div;
	int	mod;

	div = *a / *b;
	mod = *a % *b;
	*a = div;
	*b = mod;
}



#include <stdio.h>

int main() {
 
    int a = 98;
    int b = 10;
    printf("a : %d\n", a);
    printf("b : %d\n", b);
    ft_ultimate_div_mod(&a ,&b);
 
     printf("a : %d\n", a);
    printf("b : %d\n", b);

    return 0;
}

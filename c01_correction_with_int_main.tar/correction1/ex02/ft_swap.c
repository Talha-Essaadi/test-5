/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_swap.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: momousta <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/17 13:39:16 by momousta          #+#    #+#             */
/*   Updated: 2025/08/19 16:42:09 by momousta         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_swap(int *a, int *b)
{
	int	c;

	c = *a;
	*a = *b;
	*b = c;
}


#include <stdio.h>

int main() {
    // Write C code here
    int a = 1;
    int b = 2;
    printf("a : %d\n", a);
    printf("b : %d\n", b);
    ft_swap(&a ,&b);
    printf("a : %d\n", a);
    printf("b : %d\n", b);
 

    return 0;
}

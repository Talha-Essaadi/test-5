/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_ft.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: momousta <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/19 16:37:05 by momousta          #+#    #+#             */
/*   Updated: 2025/08/19 16:37:56 by momousta         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_ultimate_ft(int *********nbr)
{
	********nbr = 42;
}


#include <stdio.h>

int main()
{
int x = 5;

int *ptr1 = &x;
int **ptr2 = &ptr1;
int ***ptr3 = &ptr2;
int ****ptr4 = &ptr3;
int *****ptr5 = &ptr4;
int ******ptr6 = &ptr5;
int *******ptr7 = &ptr6;
int ********ptr8 = &ptr7;

ft_ultimate_ft(&ptr8);
printf("x : %d\n",x );
}



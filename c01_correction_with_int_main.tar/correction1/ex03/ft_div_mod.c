/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_div_mod.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: momousta <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/17 19:56:16 by momousta          #+#    #+#             */
/*   Updated: 2025/08/19 16:43:47 by momousta         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_div_mod(int a, int b, int *div, int *mod)

{
	*div = a / b;
	*mod = a % b;
}


#include <stdio.h>

int main() {
 
    int a = 98;
    int b = 10;
    int mod ;
    int div;
    printf("a : %d\n", a);
    printf("b : %d\n", b);
    ft_div_mod(a ,b, &div , &mod);
    printf("div : %d\n", div);
    printf("mod : %d\n", mod);
 

    return 0;
}
